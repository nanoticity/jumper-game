SIZE = [768, 512]

DARK_BLUE = (34, 32, 56)
WHITE = (255, 255, 255)

screen = None